package com.example.flightsdatajpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightsDataJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
