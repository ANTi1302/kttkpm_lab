package com.example.flightsdatajpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlightsDataJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlightsDataJpaApplication.class, args);
	}

}
